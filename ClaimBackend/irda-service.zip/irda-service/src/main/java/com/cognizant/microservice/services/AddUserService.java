package com.cognizant.microservice.services;

import com.cognizant.microservice.entity.UserInfo;

public interface AddUserService {
	
	String addUser(UserInfo userInfo);

}
