export interface Survey{
    claimId:string;
    policyNo:string;
    policyClass:number;
    partsCost:number;
    labourCharges:number;
    depreciationCost:number;
    totalAmount:number;
}