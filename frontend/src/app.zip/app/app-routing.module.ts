import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddSurveyComponent } from './components/add-survey/add-survey.component';
import { ViewSurveyReportComponent } from './components/view-survey-report/view-survey-report.component';

const routes: Routes = [
  { path: '', component: AddSurveyComponent },
  { path: 'viewSurvey', component: ViewSurveyReportComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
