import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SurveyorService } from 'src/app/services/surveyor.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-survey',
  templateUrl: './add-survey.component.html',
  styleUrls: ['./add-survey.component.css']
})
export class AddSurveyComponent implements OnInit {
  constructor(private service: SurveyorService, private router: Router) { }

  data: any;

  Surveyorform = new FormGroup({
    claimId: new FormControl('', [Validators.required, Validators.min(10000000000)]),
    policyNo: new FormControl('', [Validators.required, Validators.min(1000000)]),
    policyClass: new FormControl('', [Validators.required]),
    partsCost: new FormControl('', [Validators.required, Validators.min(0)]),
    labourCharges: new FormControl('', [Validators.required, Validators.min(0)]),
    depreciationCost: new FormControl('', [Validators.required])
  });

  ngOnInit(): void {}

  add() {
    this.data = this.Surveyorform.value;
    console.log(this.data);

    this.service.addSurvey(this.data).subscribe(
      data => {
        let m = data;
        Swal.fire({
          icon: 'success',
          title: `${m}\nAmount Allocated`,
          showConfirmButton: true,
        });
      },
      errorMessage => {
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Please Check Your Details and try again',
        });
        console.log(errorMessage);
      }
    );
  }
}
